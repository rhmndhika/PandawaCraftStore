import { IonAvatar, IonBadge, IonContent, IonHeader, IonImg, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import HalamanLogin from '../components/HalamanLogin';

const HalLogin: React.FC = () => {
  return (
    
    <HalamanLogin />
    
  );
};

export default HalLogin;