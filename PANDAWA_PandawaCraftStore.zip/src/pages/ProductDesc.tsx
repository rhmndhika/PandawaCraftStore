import { IonRow, IonLabel, IonCol, IonButton, IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle, IonContent, IonHeader, IonImg, IonPage, IonTitle, IonToolbar } from "@ionic/react";
import React from "react";
import ProductDeskripsi from "../components/ProductDeskripsi";



const ProductDesc: React.FC = () => {
    return (
      <ProductDeskripsi />
    );
};

export default ProductDesc;