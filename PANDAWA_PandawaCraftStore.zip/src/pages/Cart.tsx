import React from "react";
import ShoppingCart from "../components/ShoppingCart";


const Cart: React.FC = () => {
    return (
        <ShoppingCart />
    );
};

export default Cart;