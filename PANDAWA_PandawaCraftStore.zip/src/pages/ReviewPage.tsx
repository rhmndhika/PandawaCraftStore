import React from "react";
import Review from "../components/Review";


const ReviewPage: React.FC = () => {
    return (
        <Review />
    );
};

export default ReviewPage